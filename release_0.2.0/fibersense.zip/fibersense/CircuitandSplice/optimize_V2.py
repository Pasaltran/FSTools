
#
# Route Optimization with Optical budget based on Google OR-Tools
#
#  First Step is to read in the data from the spreadsheet and create a dictionary of the data
#
#
import pandas as pd
import os
import sys

def optimize_circuit_routing(nodes, edges, weights,feedback):
    # Initialize dictionaries
    distances = {}
    cables = {}
    node_visits = {}

    # Insert the Start Location to the nodes list
    nodes.insert(0, 'Start Location')
    # Populate node_visits
    for node in nodes:
        node_visits[node] = node_visits.get(node, 0) + 1
    print("Node Visits:", node_visits)

    # Identify nodes visited more than once
    nodes_to_duplicate = {node: count for node, count in node_visits.items() if count > 1}
    print(f"Nodes to duplicate: {nodes_to_duplicate}")

    # Initialize a counter for each node
    node_counters = {node: 0 for node in nodes_to_duplicate}

    # Create a list of unique nodes including duplicates
    unique_nodes = []
    for node in nodes:
        if node in nodes_to_duplicate:
            # Append the node with a suffix based on the current counter
            unique_nodes.append(f"{node}_{node_counters[node]}")
            # Increment the counter for this node
            node_counters[node] += 1
        else:
            # Append without suffix for unique nodes
            unique_nodes.append(f"{node}_0")

    print(f"Unique nodes: {unique_nodes}")

    # Mapping unique nodes to indices
    node_to_index = {node: i for i, node in enumerate(unique_nodes)}
    print(f"Node to Index: {node_to_index}")
    index_list = []
    index_list = [i for i in range(len(unique_nodes))]
    print(f"index List: {index_list}")

    # Populate distances and cables
    for i in range(len(edges)):
        node1 = unique_nodes[i]
        node2 = unique_nodes[i + 1] if i + 1 < len(unique_nodes) else unique_nodes[0]  # Loop back to start if at the end
        cable = edges[i]
        distance = weights[i]

        distances[(node1, node2)] = distance
        cables[(node1, node2)] = cable
    # Now your distances, cables dictionaries are populated with your array data
    print("Distances:", distances)
    print("Cables:", cables)


    # Create a distance matrix
    no_connection = int(1e10)  # This represents absence of connection
    matrix_size = len(unique_nodes)
    distance_matrix = [[0 if i == j else no_connection for j in range(matrix_size)] for i in range(matrix_size)]
    #cable_matrix = [[0 if i == j else no_connection for j in range(matrix_size)] for i in range(matrix_size)]

    # Populate the distance matrix with actual distances
    for (node1, node2), distance in distances.items():
        index1 = node_to_index[node1]
        index2 = node_to_index[node2]
        distance_matrix[index1][index2] = int(distance)
        distance_matrix[index2][index1] = int(distance)

    # # Print the distance matrix
    # # Getting node names sorted by index
    # node_names = sorted(node_to_index, key=node_to_index.get)

    # # Printing the header
    # print(f"{' ':<12}", end="")  # 11 characters wide plus space
    # for node in node_names:
    #     print(f"{node:<12}", end="")  # 11 characters wide plus space
    # print()

    # # Printing each row
    # for i, row in enumerate(distance_matrix):
    #     print(f"{node_names[i]:<12}", end="")  # 11 characters wide plus space
    #     for dist in row:
    #         print(f"{dist:<12}", end="")  # 11 characters wide plus space
    #     print()



    from ortools.constraint_solver import pywrapcp
    from ortools.constraint_solver import routing_enums_pb2

    # Define a dictionary mapping status codes to descriptions
    status_descriptions = {
        0: "ROUTING_NOT_SOLVED: Problem not solved yet.",
        1: "ROUTING_SUCCESS: Problem solved successfully.",
        2: "ROUTING_PARTIAL_SUCCESS_LOCAL_OPTIMUM_NOT_REACHED: Problem solved successfully after calling RoutingModel.Solve(), except that a local optimum has not been reached. Leaving more time would allow improving the solution.",
        3: "ROUTING_FAIL: No solution found to the problem.",
        4: "ROUTING_FAIL_TIMEOUT: Time limit reached before finding a solution.",
        5: "ROUTING_INVALID: Model, model parameters, or flags are not valid.",
        6: "ROUTING_INFEASIBLE: Problem proven to be infeasible.",
        7: "ROUTING_NOT_SOLVED: Problem not solved yet. More compute time may yield solution"
    }


    # Create the routing index manager and routing model.

    # Map nodes to integers
    node_to_index = {node: i for i, node in enumerate(unique_nodes)}

    # Indices for start and end nodes
    start_node = unique_nodes[0]
    end_node = unique_nodes[-1]
    print(f"Start Node: {start_node}")
    print(f"End Node: {end_node}")
    start_node_index = node_to_index[start_node]
    end_node_index = node_to_index[end_node]
    print(f'Nodes: {nodes}')
    print(f"Start node: {start_node}  Start Index {start_node_index} End node: {end_node} End Node Index: {end_node_index} Len of index list: {len(index_list)} ")

    # Assuming you have 'num_vehicles' set to a high number

    # num_vehicles = 2
    # start_node_indices = [start_node_index, start_node_index]  # Assuming both vehicles start from the same node
    # end_node_indices = [end_node_index, end_node_index]       # Assuming both vehicles end at the same node
    #manager = pywrapcp.RoutingIndexManager(matrix_size, num_vehicles, start_node_indices, end_node_indices)
    num_vehicles = 1
    #manager = pywrapcp.RoutingIndexManager(matrix_size, num_vehicles, [0])
    manager = pywrapcp.RoutingIndexManager(matrix_size, num_vehicles, [0], [len(unique_nodes)-1])

    # Create the routing model.
    routing = pywrapcp.RoutingModel(manager)

    # # Penalize unused vehicles
    # unused_vehicle_penalty = int(1e5)  # Cast to int explicitly
    # for vehicle_id in range(num_vehicles):
    #     start_index = routing.Start(vehicle_id)
    #     routing.AddDisjunction([start_index], unused_vehicle_penalty)


    # Create and register a transit callback.
    def distance_callback(from_index, to_index):
        # Returns the distance between the two nodes.
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        return distance_matrix[from_node][to_node]

    transit_callback_index = routing.RegisterTransitCallback(distance_callback)
    routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

    print(f"Matrix size: {matrix_size}")

    # Set the search parameters.
    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.LOCAL_CHEAPEST_ARC)
    search_parameters = pywrapcp.DefaultRoutingSearchParameters()
    search_parameters.local_search_metaheuristic = (
        routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH)
    if matrix_size < 60:
        search_parameters.time_limit.seconds = 15
        search_parameters.solution_limit = 1000
    elif matrix_size < 200:
        search_parameters.time_limit.seconds = 30
        search_parameters.solution_limit = 1000
    else:
        search_parameters.time_limit.seconds = 300
        search_parameters.solution_limit = 100000

    search_parameters.log_search = True
    search_parameters.use_full_propagation = False

    #
    #
    #   Adding in Constraints
    #
    #
    # Scale factor to convert costs to integers
    SCALE_FACTOR = 100000

    # Adjusted constants for budget calculation (scaled up)
    COST_PER_DISTANCE_UNIT = (0.35 / 1000) * SCALE_FACTOR  # cost for each unit of distance
    COST_PER_NODE_VISITED = 0.1 * SCALE_FACTOR
    TOTAL_BUDGET = 100 * SCALE_FACTOR  # Total budget scaled up

    # Custom callback to calculate the cost for each route segment (adjusted for integer operations)
    def budget_callback(from_index, to_index):
        # Retrieve the distance between the nodes
        from_node = manager.IndexToNode(from_index)
        to_node = manager.IndexToNode(to_index)
        distance = distance_matrix[from_node][to_node]

        # Calculate the cost for this segment (scaled up)
        distance_cost = distance * COST_PER_DISTANCE_UNIT
        node_cost = COST_PER_NODE_VISITED  # cost for visiting the node

        return int(distance_cost + node_cost)  # Ensure the result is an integer

    budget_callback_index = routing.RegisterTransitCallback(budget_callback)

    # Adding budget dimension (adjusted for integer operations)
    routing.AddDimension(
        budget_callback_index,
        0,  # no slack
        TOTAL_BUDGET,  # maximum budget per vehicle (scaled up)
        True,  # start cumul to zero
        "Budget"
    )

    budget_dimension = routing.GetDimensionOrDie("Budget")
    budget_dimension.SetGlobalSpanCostCoefficient(100)

    #
    #  End Constraints


    # Solve the problem
    print(f"Solving... Solution in {search_parameters.time_limit.seconds} seconds")
    print (f'Loading initial route with {index_list}')
    initial_solution = routing.ReadAssignmentFromRoutes([index_list], True)

    #solution = routing.SolveFromAssignmentWithParameters(initial_solution, search_parameters)
    solution = routing.SolveWithParameters(search_parameters)
    # Get the status from the solver
    solver_status = routing.status()


    # Check if a solution was found
    if solution:
        # Calculate the route distance
        index = routing.Start(0)
        route_distance = 0
        while not routing.IsEnd(index):
            next_index = solution.Value(routing.NextVar(index))
            route_distance += routing.GetArcCostForVehicle(index, next_index, 0)

            index = next_index
    if solver_status == 1 and route_distance > no_connection:
        solver_status = 7  # Infeasible
    # Look up the description and print it
    print("Solution status: ", status_descriptions.get(solver_status, "Unknown status code"))

    if solution:
        index = routing.Start(0)

        total_distance = 0
        total_load = 0
        new_nodes = []  # List to store the order of nodes visited
        new_edges = []  # List to store the edges (cables) used
        new_weights = []  # List to store the weights (distances)
        circuit_loss = []
        for vehicle_id in range(num_vehicles):
            index = routing.Start(vehicle_id)
            plan_output = f'Route for vehicle {vehicle_id}:\n'
            route_distance = 0
            route_load = 0
            while not routing.IsEnd(index):
                node = unique_nodes[manager.IndexToNode(index)]
                next_index = solution.Value(routing.NextVar(index))
                next_node = unique_nodes[manager.IndexToNode(next_index)]

                # Retrieve cable information
                cable = cables.get((node, next_node), cables.get((next_node, node), 'Unknown Cable'))
                new_edges.append(cable)

                # Remove suffix if present
                if "_" in node:
                    node = node.split("_")[0]
                new_nodes.append(node)

                # Remove suffix if present
                if "_" in next_node:
                    next_node = next_node.split("_")[0]

                distance = routing.GetArcCostForVehicle(index, next_index, 0)
                new_weights.append(distance)

                #plan_output += f'{node} -> {cable} ({distance}m) -> {next_node}\n'

                route_distance += routing.GetArcCostForVehicle(index, next_index, vehicle_id)
                route_load += budget_callback(index, next_index)  # Using the budget callback to calculate load
                circuit_loss.append(budget_callback(index, next_index)/SCALE_FACTOR)

                plan_output += f' {node} -> {cable} ({distance}m) \t-> {next_node} \tCumm Loss/Dist: ({route_load/SCALE_FACTOR} / {route_distance:,})\n'
                index = next_index

            plan_output += f' {manager.IndexToNode(index)}\n'
            plan_output += f'Distance of the route: {route_distance}m\n'
            plan_output += f'Load of the route: {route_load/SCALE_FACTOR}\n'
            print(plan_output)
            total_distance += route_distance
            total_load += route_load
        print(f'Total Distance of all routes: {total_distance:,}m')
        print(f'Total Optical Loss: {total_load/SCALE_FACTOR:.2f}db')

        # Add the last node to the nodes list as the route ends at a node
        new_nodes.append(next_node)
        del new_nodes[0]  # Remove the first node as it is the start node

        # Print the newly generated nodes, edges, and weights
        print("New Nodes:", new_nodes)
        print("New Edges:", new_edges)
        print("New Weights:", new_weights)
        print("Circuit Loss:", circuit_loss)


    return new_nodes, new_edges, new_weights, circuit_loss
    sys.exit()


    # Print the best solution found
    if solution:
        index = routing.Start(0)
        plan_output = f'Route:\n'
        while not routing.IsEnd(index):
            node = nodes[manager.IndexToNode(index)]
            next_index = solution.Value(routing.NextVar(index))
            next_node = nodes[manager.IndexToNode(next_index)]
            distance = routing.GetArcCostForVehicle(index, next_index, 0)
            # Retrieve cable information
            cable = cables.get((node, next_node), cables.get((next_node, node), 'Unknown Cable'))
            plan_output += f'{node} -> {cable} ({distance}m) -> {next_node}\n'
            index = next_index
        print(plan_output)
        print('Circuit Distance: {:,.2f} kilometers'.format(route_distance / 1000))


    # Define a dictionary mapping status codes to descriptions
    status_descriptions = {
        0: "ROUTING_NOT_SOLVED: Problem not solved yet.",
        1: "ROUTING_SUCCESS: Problem solved successfully.",
        2: "ROUTING_PARTIAL_SUCCESS_LOCAL_OPTIMUM_NOT_REACHED: Problem solved successfully after calling RoutingModel.Solve(), except that a local optimum has not been reached. Leaving more time would allow improving the solution.",
        3: "ROUTING_FAIL: No solution found to the problem.",
        4: "ROUTING_FAIL_TIMEOUT: Time limit reached before finding a solution.",
        5: "ROUTING_INVALID: Model, model parameters, or flags are not valid.",
        6: "ROUTING_INFEASIBLE: Problem proven to be infeasible.",
        7: "ROUTING_NOT_SOLVED: Problem not solved yet. More compute time may yield solution"
    }

    # Get the status from the solver
    solver_status = routing.status()
    if solver_status == 1 and route_distance > no_connection:
        solver_status = 7  # Infeasible
    # Look up the description and print it
    print("Solution status: ", status_descriptions.get(solver_status, "Unknown status code"))



    # Check if a solution was found
    if solution:
        print("Solution found!")
        total_distance = 0
        total_load = 0
        for vehicle_id in range(num_vehicles):
            index = routing.Start(vehicle_id)
            plan_output = f'Route for vehicle {vehicle_id}:\n'
            route_distance = 0
            route_load = 0
            while not routing.IsEnd(index):
                node = nodes[manager.IndexToNode(index)]
                node_index = manager.IndexToNode(index)
                next_index = solution.Value(routing.NextVar(index))
                next_node = nodes[manager.IndexToNode(next_index)]
                next_node_index = manager.IndexToNode(next_index)
                route_distance += routing.GetArcCostForVehicle(index, next_index, vehicle_id)
                # Retrieve cable information
                cable = cables.get((node, next_node), 'Unknown Cable')
                seg_distance = routing.GetArcCostForVehicle(index, next_index, 0)
                route_load += budget_callback(index, next_index)  # Using the budget callback to calculate load
    #            plan_output += f' {node} ->\t{seg_distance} \t-> {next_node} \tCumm Loss/Dist: ({route_load/SCALE_FACTOR} / {route_distance})\n'

                plan_output += f' {nodes[node_index]} -> {cable} ({seg_distance}m) \t-> {nodes[next_node_index]} \tCumm Loss/Dist: ({route_load/SCALE_FACTOR} / {route_distance:,})\n'


                index = next_index
            plan_output += f' {manager.IndexToNode(index)}\n'
            plan_output += f'Distance of the route: {route_distance}m\n'
            plan_output += f'Load of the route: {route_load/SCALE_FACTOR}\n'
            print(plan_output)
            total_distance += route_distance
            total_load += route_load
        print(f'Total Distance of all routes: {total_distance:,}m')
        print(f'Total Optical Loss: {total_load/SCALE_FACTOR:.2f}db')
    else:
        print('No solution found !')









