# -*- coding: utf-8 -*-

"""
/***************************************************************************
 Heat Map V3
                                 A QGIS plugin
 HeatMap Generation of Duct vs Utility
                              -------------------
        begin                : 2023-04-25 (V2), 2026-10 (V3)
        copyright            : (C) 2023 by Scott Buchanan - FiberSense
        email                : scott.buchanan@fibersense.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

 V3 - QGIS 4 / Qt6 (PyQt6) only. Replaced V2 (removed in 1.1.0).

 Changes from V2
   Speed
   - Offset bands are built by "peeling": for each offset k the remaining
     geometry is clipped to ONE dissolved buffer of the other layer, then that
     buffer is subtracted from what remains. No 0.01m sliver buffers, no
     per-offset merges.
   - The duct-side buffers are built from the utility already clipped to the
     duct area (V2 buffered the full utility network every offset).
   - Large utility networks (e.g. national water mains) are read ONCE: a
     spatial index of the subdivided duct search area classifies each pipe as
     near or far. Far pipes go straight to the heat map as out of range with no
     geometry operations; only near pipes are clipped/differenced. The utility
     total length is summed in the same pass. The utility is never reprojected
     (the duct is reprojected to the utility CRS if they differ).
   - The out-of-range ("Null") section near the duct is one difference against
     the single max-offset buffer (this was the V2 bottleneck).
   - Optional: leave the far network out of the output entirely.
   - Child algorithms receive feedback, so the progress bar is accurate and
     Cancel works mid-step.
   QGIS 4 / PyQt6
   - QMetaType field types (QVariant.String/Int do not exist in PyQt6).
   - Qgis.* scoped enums, TEMPORARY_OUTPUT, native:savefeatures.
   - Layers are added to the project in postProcessAlgorithm (main thread),
     not from the processing worker thread.
   Bug fixes
   - Three color mode works above offset 10 (7+ is red).
   - Both heat maps are saved to file (V2 saved only the utility heat map).
   - Results table total row is aligned with its columns.
   - Selected-features-only inputs are respected.
   - Different layer CRSs are handled; geographic CRS (degrees) is rejected.
"""

__author__ = 'Scott Buchanan - FiberSense'
__date__ = '2026-10-15'
__copyright__ = '(C) 2023 by Scott Buchanan - FiberSense'
__revision__ = '$Format:%H$'

import os

from qgis import processing
from qgis.PyQt.QtCore import QCoreApplication, QMetaType, QThread
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.core import (
    Qgis,
    QgsApplication,
    QgsCategorizedSymbolRenderer,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsMemoryProviderUtils,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingFeatureSource,
    QgsProcessingMultiStepFeedback,
    QgsProcessingOutputVectorLayer,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingUtils,
    QgsProject,
    QgsRendererCategory,
    QgsLineSymbol,
    QgsSimpleLineSymbolLayer,
    QgsSpatialIndex,
    QgsVectorLayer,
    QgsWkbTypes,
)

# Segments per quarter circle for the offset buffers. 1 matches the old V2 results so
# results can be compared. Higher values give truer distances but run slower.
BUFFER_SEGMENTS = 1

TEMP = QgsProcessing.TEMPORARY_OUTPUT

# Results table naming. Excel sheet names are limited to 31 characters; the
# table name is used as the sheet name. Each input layer contributes up to 13
# characters (13 + "_" + 13 = 27), leaving room for a "_2".."_999" suffix.
EXCEL_SHEET_MAX = 31
LAYER_NAME_PART = 13


class HeatMapV3Algorithm(QgsProcessingAlgorithm):

    INPUT = 'INPUT'
    UTILITY_INPUT = 'UTILITY_INPUT'
    BUFFERDIST_MAX = 'BUFFERDIST_MAX'
    THREE_COLOR = 'THREE_COLOR'
    LINE_WIDTH = 'LINE_WIDTH'
    INCLUDE_FAR = 'INCLUDE_FAR'
    OUTPUT = 'OUTPUT'
    EXCEL_OUTPUT = 'EXCEL_OUTPUT'
    KMZ_OUTPUT = 'KMZ_OUTPUT'

    DUCT_HEATMAP = 'DUCT_HEATMAP'
    UTILITY_HEATMAP = 'UTILITY_HEATMAP'
    RESULTS_TABLE = 'RESULTS_TABLE'

    # ------------------------------------------------------------------ #
    # Parameters
    # ------------------------------------------------------------------ #
    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, self.tr('Duct or Fiber Layer'),
            types=[Qgis.ProcessingSourceType.VectorLine]))

        self.addParameter(QgsProcessingParameterFeatureSource(
            self.UTILITY_INPUT, self.tr('Utility / Asset being Monitored Layer'),
            types=[Qgis.ProcessingSourceType.VectorLine]))

        self.addParameter(QgsProcessingParameterNumber(
            self.BUFFERDIST_MAX, self.tr('Input Offset Distance (1-25)'),
            type=Qgis.ProcessingNumberParameterType.Integer,
            defaultValue=10, minValue=1, maxValue=25))

        self.addParameter(QgsProcessingParameterBoolean(
            self.THREE_COLOR, self.tr('Three Color Heat Map'), defaultValue=False))

        self.addParameter(QgsProcessingParameterBoolean(
            self.INCLUDE_FAR,
            self.tr('Include the whole Utility network beyond the max offset (black lines)'),
            defaultValue=True))

        param = QgsProcessingParameterNumber(
            self.LINE_WIDTH, self.tr('Line Width of Heat Map Lines (Max=3)'),
            type=Qgis.ProcessingNumberParameterType.Double,
            defaultValue=2, minValue=0.01, maxValue=3)
        param.setFlags(param.flags() | Qgis.ProcessingParameterFlag.Advanced)
        param.setMetadata({'widget_wrapper': {'decimals': 2}})
        self.addParameter(param)

        self.addParameter(QgsProcessingParameterFileDestination(
            self.OUTPUT, self.tr('Save Heat Maps to file (one file per heat map)'),
            fileFilter='GeoPackage (*.gpkg);;ESRI Shapefile (*.shp)',
            optional=True, createByDefault=False))

        self.addParameter(QgsProcessingParameterFileDestination(
            self.EXCEL_OUTPUT, self.tr('Excel Output of results table'),
            fileFilter='Excel (*.xlsx)', optional=True, createByDefault=False))

        self.addParameter(QgsProcessingParameterFileDestination(
            self.KMZ_OUTPUT, self.tr('KMZ Output of the Heat Maps (one file per heat map)'),
            fileFilter='KMZ (*.kmz)', optional=True, createByDefault=False))

        self.addOutput(QgsProcessingOutputVectorLayer(
            self.DUCT_HEATMAP, self.tr('Duct heat map')))
        self.addOutput(QgsProcessingOutputVectorLayer(
            self.UTILITY_HEATMAP, self.tr('Utility heat map')))
        self.addOutput(QgsProcessingOutputVectorLayer(
            self.RESULTS_TABLE, self.tr('Results table')))

    # ------------------------------------------------------------------ #
    # Processing
    # ------------------------------------------------------------------ #
    def processAlgorithm(self, parameters, context, feedback):
        # Layers to add to the project in postProcessAlgorithm (main thread)
        self._to_load = []      # (layer_id, saved_file_path or None)

        duct_source = self.parameterAsSource(parameters, self.INPUT, context)
        utility_source = self.parameterAsSource(parameters, self.UTILITY_INPUT, context)
        if duct_source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))
        if utility_source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.UTILITY_INPUT))

        max_offset = self.parameterAsInt(parameters, self.BUFFERDIST_MAX, context)
        three_color = self.parameterAsBool(parameters, self.THREE_COLOR, context)
        line_width = self.parameterAsDouble(parameters, self.LINE_WIDTH, context)
        file_output = self.parameterAsFileOutput(parameters, self.OUTPUT, context)
        excel_output = self.parameterAsFileOutput(parameters, self.EXCEL_OUTPUT, context)
        kmz_output = self.parameterAsFileOutput(parameters, self.KMZ_OUTPUT, context)

        include_far = self.parameterAsBool(parameters, self.INCLUDE_FAR, context)

        duct_name = duct_source.sourceName()
        utility_name = utility_source.sourceName()
        # Work in the Utility CRS: the (very large) utility network is never
        # reprojected; the much smaller duct layer is reprojected if needed.
        crs = utility_source.sourceCrs()

        # --- CRS checks --------------------------------------------------
        if crs.isGeographic():
            raise QgsProcessingException(self.tr(
                'The Utility layer uses a geographic CRS ({0}), so offsets would be in '
                'degrees. Reproject to a projected CRS in metres first (see the '
                '"Select Best CRS" tool).').format(crs.authid()))
        if crs.mapUnits() != Qgis.DistanceUnit.Meters:
            feedback.pushWarning(self.tr(
                'Utility layer CRS units are not metres. Offsets and lengths are in '
                'the CRS units of {0}.').format(crs.authid()))

        # Multi-step feedback: accurate progress bar and cancel inside child algs
        total_steps = 17 + 6 * max_offset
        multi = QgsProcessingMultiStepFeedback(total_steps, feedback)
        self._step = 0

        def next_step(message=None):
            if multi.isCanceled():
                raise QgsProcessingException(self.tr('Canceled by user'))
            multi.setCurrentStep(self._step)
            self._step += 1
            if message:
                feedback.pushInfo(message)

        def run(alg_id, params):
            params = dict(params)
            params.setdefault('OUTPUT', TEMP)
            return processing.run(alg_id, params, is_child_algorithm=True,
                                  context=context, feedback=multi)['OUTPUT']

        def layer(layer_id):
            return QgsProcessingUtils.mapLayerFromString(layer_id, context)

        def heatmap_layer(name, wkb_type):
            fields = QgsFields()
            fields.append(QgsField('Offset', QMetaType.Type.Int))
            fields.append(QgsField('Source', QMetaType.Type.QString))
            fields.append(QgsField('Length', QMetaType.Type.Double))
            return QgsMemoryProviderUtils.createMemoryLayer(
                'Results_{0}_heatmap_V3'.format(name), fields,
                QgsWkbTypes.multiType(wkb_type), crs)

        def add_batch(target, features, what):
            if not features:
                return
            ok, _ = target.dataProvider().addFeatures(features)
            if not ok:
                raise QgsProcessingException(self.tr('Could not build {0}: {1}').format(
                    what, target.dataProvider().lastError()))
            features.clear()

        # --- Preparation --------------------------------------------------
        next_step(self.tr('Preparing layers'))
        duct_full = parameters[self.INPUT]
        # Invalid geometry makes GEOS fail part-way through a long run. The duct
        # is small: check it here and fix it once if needed, before any child
        # algorithm reads it. (The utility is checked during its single scan.)
        n_invalid = self.count_invalid(duct_source)
        if n_invalid:
            feedback.pushWarning(self.tr('{0}: {1} invalid geometries, fixing them').format(
                duct_name, n_invalid))
            duct_full = run('native:fixgeometries', {'INPUT': duct_full, 'METHOD': 1})
        else:
            feedback.pushInfo(self.tr('{0}: geometries valid').format(duct_name))
        duct_reprojected = duct_source.sourceCrs() != crs
        if duct_reprojected:
            feedback.pushInfo(self.tr('Reprojecting the Duct layer to {0}').format(crs.authid()))
            duct_full = run('native:reprojectlayer', {
                'INPUT': duct_full, 'TARGET_CRS': crs})

        next_step(self.tr('Dissolving the Duct layer'))
        duct_diss = run('native:dissolve', {
            'INPUT': duct_full, 'FIELD': [], 'SEPARATE_DISJOINT': False})

        next_step(self.tr('Building the Duct search area'))
        duct_area = run('native:buffer', {
            'INPUT': duct_diss, 'DISTANCE': max_offset + 1, 'SEGMENTS': 5,
            'END_CAP_STYLE': 0, 'JOIN_STYLE': 0, 'MITER_LIMIT': 2, 'DISSOLVE': True})

        # Cut the search area into small pieces with tight bounding boxes so the
        # spatial index rejects almost every far-away pipe without a geometry test
        next_step()
        area_pieces = run('native:subdivide', {'INPUT': duct_area, 'MAX_NODES': 256})
        next_step()
        area_pieces = run('native:multiparttosingleparts', {'INPUT': area_pieces})

        # --- Single pass over the (very large) utility network -------------
        next_step(self.tr('Scanning the {0} network').format(utility_name))
        index = QgsSpatialIndex()
        engines = {}
        for piece in layer(area_pieces).getFeatures():
            pg = piece.geometry()
            if pg.isEmpty():
                continue
            index.addFeature(piece)
            engine = QgsGeometry.createGeometryEngine(pg.constGet())
            engine.prepareGeometry()
            engines[piece.id()] = (pg, engine)   # keep pg alive with its engine

        utility_heatmap = heatmap_layer(utility_name, utility_source.wkbType())
        hm_fields = utility_heatmap.fields()
        candidates = QgsMemoryProviderUtils.createMemoryLayer(
            'utility_candidates', QgsFields(), utility_source.wkbType(), crs)
        context.temporaryLayerStore().addMapLayer(candidates)

        utility_total = 0.0
        n_total = utility_source.featureCount()
        n_near = n_far = 0
        n_fixed = n_dropped = 0
        utility_multi = QgsWkbTypes.isMultiType(utility_source.wkbType())
        near_batch, far_batch = [], []
        request = QgsFeatureRequest().setNoAttributes()
        # Validity is checked here, pipe by pipe, so the network is read only once
        skip_checks = QgsProcessingFeatureSource.Flag.FlagSkipGeometryValidityChecks
        for i, f in enumerate(utility_source.getFeatures(request, skip_checks)):
            if i % 5000 == 0:
                if multi.isCanceled():
                    raise QgsProcessingException(self.tr('Canceled by user'))
                if n_total and n_total > 0:
                    multi.setProgress(100.0 * i / n_total)
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            if not g.isGeosValid():
                g = self.fix_line(g, utility_multi)
                if g is None:
                    n_dropped += 1
                    continue
                n_fixed += 1
            length = g.length()
            utility_total += length
            near = False
            for pid in index.intersects(g.boundingBox()):
                if engines[pid][1].intersects(g.constGet()):
                    near = True
                    break
            if near:
                cf = QgsFeature()
                cf.setGeometry(g)
                near_batch.append(cf)
                n_near += 1
                if len(near_batch) >= 10000:
                    add_batch(candidates, near_batch, 'utility candidates')
            else:
                n_far += 1
                if include_far:
                    g.convertToMultiType()
                    nf = QgsFeature(hm_fields)
                    nf.setGeometry(g)
                    nf.setAttributes([None, utility_name, round(length, 2)])
                    far_batch.append(nf)
                    if len(far_batch) >= 10000:
                        add_batch(utility_heatmap, far_batch, 'the utility heat map')
        add_batch(candidates, near_batch, 'utility candidates')
        add_batch(utility_heatmap, far_batch, 'the utility heat map')
        del index, engines
        feedback.pushInfo(self.tr('{0}: {1} features near the Duct, {2} beyond it{3}').format(
            utility_name, n_near, n_far, '' if include_far else ' (not included)'))
        if n_fixed or n_dropped:
            feedback.pushWarning(self.tr(
                '{0}: fixed {1} invalid geometries, skipped {2} that could not be '
                'repaired as lines').format(utility_name, n_fixed, n_dropped))
        else:
            feedback.pushInfo(self.tr('{0}: geometries valid').format(utility_name))

        # Native clip warns when its input has no spatial index. Here the overlay
        # is a single feature so the index barely changes speed, but it is cheap
        # and keeps the log readable.
        candidates.dataProvider().createSpatialIndex()

        next_step(self.tr('Isolating the Utility near the Duct'))
        utility_near = run('native:clip', {'INPUT': candidates, 'OVERLAY': duct_area})

        next_step(self.tr('Dissolving the Utility layer'))
        utility_diss = run('native:dissolve', {
            'INPUT': utility_near, 'FIELD': [], 'SEPARATE_DISJOINT': False})

        # --- Offset bands ("peeling") --------------------------------------
        def build_bands(label, target, other):
            """For k = 1..max: band_k = remaining clipped to buffer(other, k);
            remaining = remaining minus buffer(other, k).
            Returns {k: band_layer_id} and the max-offset buffer id."""
            bands = {}
            remaining = target
            buf = None
            for k in range(1, max_offset + 1):
                next_step(self.tr('{0}: offset {1}/{2}').format(label, k, max_offset))
                buf = run('native:buffer', {
                    'INPUT': other, 'DISTANCE': k, 'SEGMENTS': BUFFER_SEGMENTS,
                    'END_CAP_STYLE': 0, 'JOIN_STYLE': 0, 'MITER_LIMIT': 2,
                    'DISSOLVE': True})
                next_step()
                layer(remaining).dataProvider().createSpatialIndex()
                bands[k] = run('native:clip', {'INPUT': remaining, 'OVERLAY': buf})
                next_step()
                remaining = run('native:difference', {'INPUT': remaining, 'OVERLAY': buf})
            return bands, buf

        utility_bands, utility_max_buf = build_bands(utility_name, utility_diss, duct_diss)
        duct_bands, duct_max_buf = build_bands(duct_name, duct_diss, utility_diss)

        # --- Out of range (Null) sections -------------------------------------
        # Utility: only the near-duct candidates need a geometry difference; the
        # far-away network was already written to the heat map during the scan.
        next_step(self.tr('Calculating the out of range section of {0}').format(utility_name))
        utility_null = run('native:difference', {'INPUT': candidates, 'OVERLAY': utility_max_buf})
        next_step(self.tr('Calculating the out of range section of {0}').format(duct_name))
        duct_null = run('native:difference', {'INPUT': duct_full, 'OVERLAY': duct_max_buf})

        # --- Build the heat map layers ------------------------------------
        def fill_heatmap(out, name, bands, null_id):
            fields = out.fields()
            lengths = {}
            batch = []

            def collect(layer_id, offset):
                total = 0.0
                for f in layer(layer_id).getFeatures():
                    if multi.isCanceled():
                        raise QgsProcessingException(self.tr('Canceled by user'))
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    g.convertToMultiType()
                    length = g.length()
                    total += length
                    nf = QgsFeature(fields)
                    nf.setGeometry(g)
                    nf.setAttributes([offset, name, round(length, 2)])
                    batch.append(nf)
                    if len(batch) >= 10000:
                        add_batch(out, batch, 'the {0} heat map'.format(name))
                return total

            for k in range(1, max_offset + 1):
                lengths[k] = collect(bands[k], k)
            collect(null_id, None)
            add_batch(out, batch, 'the {0} heat map'.format(name))
            self.categorize_line(out, max_offset, three_color, line_width)
            context.temporaryLayerStore().addMapLayer(out)
            return lengths

        next_step(self.tr('Creating the {0} Heat Map').format(duct_name))
        duct_heatmap = heatmap_layer(duct_name, duct_source.wkbType())
        duct_lengths = fill_heatmap(duct_heatmap, duct_name, duct_bands, duct_null)
        next_step(self.tr('Creating the {0} Heat Map').format(utility_name))
        utility_lengths = fill_heatmap(utility_heatmap, utility_name, utility_bands, utility_null)

        # --- Results table ------------------------------------------------
        # utility_total was summed during the network scan (full network)
        if duct_reprojected:
            duct_total = self.total_length(layer(duct_full), multi)
        else:
            duct_total = self.total_length(duct_source, multi)

        table_name = self.results_table_name(file_output, duct_name, utility_name)
        feedback.pushInfo(self.tr('Results table: {0}').format(table_name))

        results = self.build_results_table(table_name, duct_name, utility_name, max_offset,
                                           duct_total, utility_total,
                                           duct_lengths, utility_lengths)
        context.temporaryLayerStore().addMapLayer(results)

        # --- Optional outputs ---------------------------------------------
        heatmaps = ((duct_name, duct_heatmap), (utility_name, utility_heatmap))

        saved = {}
        for name, hm in heatmaps:
            next_step()
            if file_output:
                base, ext = os.path.splitext(file_output)
                if ext.lower() not in ('.gpkg', '.shp'):
                    ext = '.gpkg'
                path = '{0}_{1}_heatmap{2}'.format(base, self.safe_name(name), ext)
                feedback.pushInfo(self.tr('Saving heat map to {0}').format(path))
                saved[hm.id()] = run('native:savefeatures', {'INPUT': hm, 'OUTPUT': path})

        for name, hm in heatmaps:
            next_step()
            if kmz_output:
                base, _ = os.path.splitext(kmz_output)
                path = '{0}_{1}_heatmap.kmz'.format(base, self.safe_name(name))
                self.export_kmz(hm, path, line_width + 1, context, multi)

        next_step()
        if excel_output:
            if not excel_output.lower().endswith('.xlsx'):
                excel_output += '.xlsx'
            feedback.pushInfo(self.tr('Creating Excel file {0}').format(excel_output))
            try:
                processing.run('native:exporttospreadsheet', {
                    'LAYERS': [results], 'USE_ALIAS': True, 'FORMATTED_VALUES': False,
                    'OUTPUT': excel_output, 'OVERWRITE': True},
                    is_child_algorithm=True, context=context, feedback=multi)
            except Exception as exc:  # keep the layers even if Excel fails
                feedback.reportError(self.tr('Excel export failed: {0}').format(exc))

        for _, hm in heatmaps:
            self._to_load.append((hm.id(), saved.get(hm.id())))
        self._to_load.append((results.id(), None))

        multi.setCurrentStep(total_steps)
        return {self.DUCT_HEATMAP: duct_heatmap.id(),
                self.UTILITY_HEATMAP: utility_heatmap.id(),
                self.RESULTS_TABLE: results.id()}

    def prepareAlgorithm(self, parameters, context, feedback):
        """Runs on the main thread before processAlgorithm: snapshot the layer
        names already in the project so the results table name can be made
        unique without touching QgsProject from the worker thread."""
        self._existing_names = {lyr.name() for lyr in QgsProject.instance().mapLayers().values()}
        return True

    def results_table_name(self, file_output, duct_name, utility_name):
        """Name for the results table (also the Excel sheet name, max 31 chars).
        Uses the output file name the user entered, otherwise the first
        characters of each input layer name. A _2, _3, ... suffix is added if
        the name is already used in the project (e.g. batch runs)."""
        if file_output:
            base = self.safe_name(os.path.splitext(os.path.basename(file_output))[0])[:LAYER_NAME_PART * 2 + 1]
        else:
            base = '{0}_{1}'.format(self.safe_name(duct_name)[:LAYER_NAME_PART].rstrip('_'),
                                    self.safe_name(utility_name)[:LAYER_NAME_PART].rstrip('_'))
        existing = getattr(self, '_existing_names', set())
        name, n = base, 2
        while name in existing:
            suffix = '_{0}'.format(n)
            name = base[:EXCEL_SHEET_MAX - len(suffix)] + suffix
            n += 1
        return name

    def postProcessAlgorithm(self, context, feedback):
        """Runs on the main thread: add the result layers to the project.
        When V3 runs inside a model / another algorithm this can be called from
        a worker thread; then just return the layer ids and add nothing."""
        if QThread.currentThread() != QCoreApplication.instance().thread():
            return {}
        project = QgsProject.instance()
        for layer_id, saved_path in getattr(self, '_to_load', []):
            temp_layer = context.takeResultLayer(layer_id)
            if temp_layer is None:
                continue
            if saved_path:
                file_layer = QgsVectorLayer(saved_path, temp_layer.name(), 'ogr')
                if file_layer.isValid():
                    file_layer.setRenderer(temp_layer.renderer().clone())
                    project.addMapLayer(file_layer)
                    continue
                feedback.pushWarning(self.tr('Could not load saved file {0}; '
                                             'adding temporary layer').format(saved_path))
            project.addMapLayer(temp_layer)
        return {}

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def safe_name(name):
        return ''.join(c if c.isalnum() or c in '-_' else '_' for c in name)

    @staticmethod
    def total_length(source, feedback):
        total = 0.0
        for f in source.getFeatures():
            if feedback.isCanceled():
                break
            total += f.geometry().length()
        return total

    @staticmethod
    def offset_color(offset, max_offset, three_color):
        if three_color:
            if offset <= 3:
                return QColor(0, 255, 0)        # Green
            if offset <= 6:
                return QColor(255, 255, 0)      # Yellow
            return QColor(255, 0, 0)            # Red
        if max_offset <= 10:
            ten = {1: (0, 255, 0), 2: (64, 255, 0), 3: (128, 255, 0),
                   4: (192, 255, 0), 5: (255, 255, 0), 6: (255, 224, 0),
                   7: (255, 192, 0), 8: (255, 128, 0), 9: (255, 64, 0),
                   10: (255, 0, 0)}
            return QColor(*ten[offset])
        wide = {1: (0, 255, 0), 2: (128, 255, 0), 3: (192, 255, 0), 4: (234, 255, 0),
                5: (255, 255, 0), 6: (255, 255, 128), 7: (255, 192, 203),
                8: (255, 127, 80), 9: (255, 69, 0), 10: (139, 0, 0), 11: (128, 0, 0)}
        # 12..25: 145, 150, ... 210 (same as V2)
        wide.update({k: (145 + (k - 12) * 5, 0, 0) for k in range(12, 26)})
        return QColor(*wide[offset])

    def categorize_line(self, lyr, max_offset, three_color, line_width):
        def line_symbol(color, width):
            # Built directly (not from the project default symbol) so nothing
            # touches QgsProject from the processing worker thread
            sl = QgsSimpleLineSymbolLayer()
            sl.setColor(color)
            sl.setWidth(width)
            return QgsLineSymbol([sl])

        categories = [
            QgsRendererCategory(k, line_symbol(self.offset_color(k, max_offset, three_color),
                                               line_width), str(k))
            for k in range(1, max_offset + 1)]
        categories.append(QgsRendererCategory(
            None, line_symbol(QColor(0, 0, 0), line_width * 0.25), 'Out of range or Null'))
        lyr.setRenderer(QgsCategorizedSymbolRenderer('Offset', categories))

    def build_results_table(self, table_name, duct_name, utility_name, max_offset,
                            duct_total, utility_total, duct_lengths, utility_lengths):
        lyr = QgsVectorLayer('None', table_name, 'memory')
        pr = lyr.dataProvider()
        pr.addAttributes([
            QgsField('Name', QMetaType.Type.QString),
            QgsField('OffsetDist', QMetaType.Type.Int),
            QgsField('UtilLen', QMetaType.Type.Int),
            QgsField('UtilCummLen', QMetaType.Type.Int),
            QgsField('UtilPctCovered', QMetaType.Type.QString),
            QgsField('DuctLen', QMetaType.Type.Int),
            QgsField('DuctCummLen', QMetaType.Type.Int),
            QgsField('DuctPctCovered', QMetaType.Type.QString),
        ])
        lyr.updateFields()

        def pct(part, whole):
            return '{0}%'.format(int(part / whole * 100)) if whole else ''

        pair = '{0}/{1}'.format(duct_name, utility_name)
        rows = []
        util_cumm = duct_cumm = 0.0
        for k in range(1, max_offset + 1):
            util_cumm += utility_lengths[k]
            duct_cumm += duct_lengths[k]
            f = QgsFeature(lyr.fields())
            f.setAttributes([pair, k,
                             int(utility_lengths[k]), int(util_cumm), pct(util_cumm, utility_total),
                             int(duct_lengths[k]), int(duct_cumm), pct(duct_cumm, duct_total)])
            rows.append(f)
        # Last row: total lengths of each input layer
        total = QgsFeature(lyr.fields())
        total.setAttributes([pair + ' (total length)', 0, int(utility_total), None, None,
                             int(duct_total), None, None])
        rows.append(total)
        ok, _ = pr.addFeatures(rows)
        if not ok:
            raise QgsProcessingException(self.tr(
                'Could not build the results table: {0}').format(pr.lastError()))

        aliases = {
            'Name': 'Duct / Utility',
            'OffsetDist': 'Offset Distance - Meters',
            'UtilLen': 'Utility Incremental Coverage increase with increased offset - Meters',
            'UtilCummLen': 'Cummulative Utility Length Monitored - Meters',
            'UtilPctCovered': 'Percentage of Utility Covered',
            'DuctLen': 'Duct Incremental Coverage increase with increased offset - Meters',
            'DuctCummLen': 'Cummulative Duct Length Used - Meters',
            'DuctPctCovered': 'Percentage of Duct Utilized',
        }
        for field, alias in aliases.items():
            lyr.setFieldAlias(lyr.fields().lookupField(field), alias)
        return lyr

    def export_kmz(self, lyr, path, line_width_factor, context, feedback):
        alg_id = 'kmltools:exportkmz'
        if QgsApplication.processingRegistry().algorithmById(alg_id) is None:
            feedback.pushWarning(self.tr('KML Tools plugin not available; KMZ not created.'))
            return
        feedback.pushInfo(self.tr('Creating KMZ file {0}').format(path))
        # KML Tools cannot export curved geometry (CompoundCurve / CircularString).
        # Convert curves to short straight segments for the KMZ copy only; the
        # heat map layer and GPKG keep the true curves. The layer's declared type
        # is not enough: clip/difference can leave CompoundCurve features in a
        # LineString layer, so check the features too.
        if QgsWkbTypes.isCurvedType(lyr.wkbType()) or self.has_curved_features(lyr):
            feedback.pushInfo(self.tr('Converting curved geometry to straight segments for KMZ'))
            try:
                linear_id = processing.run('native:segmentizebymaxangle', {
                    'INPUT': lyr, 'ANGLE': 2, 'OUTPUT': TEMP},
                    is_child_algorithm=True, context=context, feedback=feedback)['OUTPUT']
                linear = QgsProcessingUtils.mapLayerFromString(linear_id, context)
                linear.setRenderer(lyr.renderer().clone())
                lyr = linear
            except Exception as exc:
                feedback.reportError(self.tr('Could not convert curves for {0}: {1}').format(path, exc))
                return
        params = {
            'InputLayer': lyr,
            'SelectedFeaturesOnly': False,
            'NameField': 'Offset',
            'HiddenPolygonPointLabel': False,
            'DescriptionField': [f.name() for f in lyr.fields()],
            'ExportStyle': True,
            'UseGoogleIcon': None,
            'AltitudeInterpretation': 1,
            'AltitudeMode': 0,
            'AltitudeModeField': '',
            'AltitudeField': '',
            'AltitudeAddend': 0,
            'ExtendSidesToGround': False,
            'DateTimeStampField': '',
            'DateTimeBeginField': '',
            'DateTimeEndField': '',
            'PhotoField': '',
            'LineWidthFactor': line_width_factor,
            'SubFolderField': 'Offset',
            'DateStampField': '',
            'TimeStampField': '',
            'DateBeginField': '',
            'TimeBeginField': '',
            'DateEndField': '',
            'TimeEndField': '',
            'OutputKmz': path,
        }
        try:
            processing.run(alg_id, params, is_child_algorithm=True,
                           context=context, feedback=feedback)
        except Exception as exc:  # KMZ is optional: report but keep the results
            feedback.reportError(self.tr('KMZ export failed for {0}: {1}').format(path, exc))

    @staticmethod
    def count_invalid(source):
        """Number of features whose geometry GEOS reports as invalid."""
        request = QgsFeatureRequest().setNoAttributes()
        flags = QgsProcessingFeatureSource.Flag.FlagSkipGeometryValidityChecks
        return sum(1 for f in source.getFeatures(request, flags)
                   if f.hasGeometry() and not f.geometry().isGeosValid())

    @staticmethod
    def fix_line(g, multi):
        """Repair an invalid line geometry; None if nothing usable is left
        (e.g. a pipe that collapses to a point)."""
        fixed = g.makeValid()
        if fixed.isNull() or fixed.isEmpty():
            return None
        lines = fixed.convertToType(Qgis.GeometryType.Line, multi)
        if lines.isNull() or lines.isEmpty():
            return None
        return lines

    @staticmethod
    def has_curved_features(lyr):
        """True if any feature geometry is curved (stops at the first one)."""
        request = QgsFeatureRequest().setNoAttributes()
        for f in lyr.getFeatures(request):
            if f.hasGeometry() and QgsWkbTypes.isCurvedType(f.geometry().wkbType()):
                return True
        return False

    # ------------------------------------------------------------------ #
    # Metadata
    # ------------------------------------------------------------------ #
    def name(self):
        return 'heatmapv3'

    def displayName(self):
        return self.tr('Heat Map Generation V3')

    def group(self):
        return self.tr(self.groupId())

    def groupId(self):
        return ''

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return HeatMapV3Algorithm()

    def shortHelpString(self):
        return self.tr(
            '<b>Heat Map V3</b> - Colorized breakdown of the sensing area (QGIS 4).<br>'
            'Generates two offset heat maps: the Utility coloured by distance from '
            'the Duct, and the Duct coloured by distance from the Utility. Sections '
            'beyond the max offset are drawn thin black ("Out of range or Null").<br>'
            '<b>Duct or Fiber Layer:</b> duct or carrier circuit layer.<br>'
            '<b>Utility Layer:</b> utility being monitored (water, gas, ...).<br>'
            '<b>Input Offset Distance:</b> integer 1 to 25 (metres). Layers must use '
            'a projected CRS in metres.<br>'
            '<b>Three Color Heat Map:</b> green 1-3, yellow 4-6, red 7+.<br>'
            '<b>Include the whole Utility network:</b> on (default, same as V2) copies '
            'every utility feature beyond the max offset into the heat map as black '
            'lines. Turn off for national-scale networks to get a much smaller, faster '
            'output containing only the area around the Duct. Percentages always use '
            'the full Utility length.<br>'
            '<b>Line Width (advanced):</b> 0.01 to 3.0, default 2.<br>'
            '<b>OUTPUT FILES - Optional</b><br>'
            '<b>Save Heat Maps to file:</b> GPKG or SHP; one file per heat map, '
            'named &lt;name&gt;_&lt;layer&gt;_heatmap.<br>'
            '<b>Excel Output:</b> the results table.<br>'
            '<b>KMZ Output:</b> one KMZ per heat map (requires the KML Tools plugin).')

    def icon(self):
        return QIcon(os.path.join(os.path.dirname(__file__), 'HeatMapIcon.png'))
